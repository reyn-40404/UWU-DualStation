#!/usr/bin/env bash
# 檢查 bilibili.apks（bundletool 產生的分割 APK 集合）：
# 列出內容結構、套件名稱、versionName / versionCode、啟動 Activity。
# 唯讀：只解壓到暫存資料夾，不會安裝、更新或修改任何東西。
#
# 需求：unzip，以及 Android SDK build-tools 內的 aapt2
# 用法：tools/inspect_apks.sh /path/to/bilibili.apks
set -euo pipefail

APKS="${1:?用法: tools/inspect_apks.sh /path/to/bilibili.apks}"
[ -f "$APKS" ] || { echo "找不到檔案：$APKS" >&2; exit 1; }

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
unzip -q "$APKS" -d "$WORK"

echo "== .apks 內容結構 =="
(cd "$WORK" && find . -type f | sort)
echo

BASE="$(find "$WORK" \( -name 'base-master.apk' -o -name 'base.apk' \) | head -n1)"
[ -n "$BASE" ] || BASE="$(find "$WORK" -name '*.apk' | head -n1)"
[ -n "$BASE" ] || { echo "壓縮檔內沒有任何 .apk" >&2; exit 1; }

AAPT2="$(command -v aapt2 || true)"
if [ -z "$AAPT2" ]; then
  SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
  AAPT2="$(ls "$SDK"/build-tools/*/aapt2 2>/dev/null | sort -V | tail -n1 || true)"
fi
[ -n "$AAPT2" ] || { echo "找不到 aapt2。請安裝 Android SDK build-tools，或設定 ANDROID_HOME。" >&2; exit 1; }

echo "== 以 $(basename "$BASE") 解析 =="
"$AAPT2" dump badging "$BASE" | grep -E "^(package:|sdkVersion|targetSdkVersion|application-label:|launchable-activity)" || true
echo
echo "分割 APK 數量：$(find "$WORK" -name '*.apk' | wc -l)"
echo
echo "請把上面 package: name='...' 的值填入 gradle.properties 的 uwu.bilibiliPackage，"
echo "versionName 則可填入 uwu.bilibiliExpectedVersionName（選填）。"
