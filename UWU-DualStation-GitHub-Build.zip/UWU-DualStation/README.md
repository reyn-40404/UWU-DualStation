# 雙站 UWU（DualStation UWU）— v0.1

「雙站啟動器」：打開 UWU，從首頁用合法的 Android Intent 開啟手機上**已安裝**的 YouTube 與 Bilibili。
不使用 WebView、不修改或重新封裝任何官方 APK、不混合兩平台影片、不下載／更新／替換 Bilibili。

- 套件名稱：`com.uwu.dualstation`
- Kotlin、Jetpack Compose（Material 3）
- minSdk 26（Android 8.0）、targetSdk / compileSdk 35
- 不需要 Root、不需要虛擬機

## v0.1 已完成

- 首頁：YouTube 入口、Bilibili 入口、下載中心與設定（後兩者先顯示「即將推出」）
- 以 `PackageManager` 檢查安裝狀態與 versionName / versionCode
- 圖示取自手機上已安裝 App 的原生圖示（專案內不含任何平台商標圖檔）
- **Bilibili 套件名稱是 App 內可修改的設定值**（預設為空，UWU 不內建、不猜測）
- 錯誤處理：未設定、未安裝／套件名稱不正確、無啟動入口、啟動失敗，皆以 Snackbar 說明
- Android 11+ 套件可見性：`<queries>` 宣告 YouTube 套件與「桌面 App」intent，未使用 `QUERY_ALL_PACKAGES`
- 每次回到 UWU 會重新檢查安裝狀態

## 設定 Bilibili（App 內，不用重新編譯）

1. 開啟 UWU，在 Bilibili 卡片按「**設定套件**」。
2. 兩種方式擇一：
   - 按「**從已安裝的 App 清單選擇**」，搜尋「bili」或「哔哩」，點選你的舊國際版（清單會同時顯示套件名稱）。
   - 或手動輸入套件名稱（用下面的方法查出）。
3. 「預期版本號」選填：填入你要保留的舊版 versionName，之後若手機上的版本不同，卡片會用紅字提醒（只提醒，不會動手機上的 App）。
4. 儲存後卡片會顯示套件名稱與版本號，按「開啟」即可。

> 注意：如果手機上同時裝了多個 Bilibili 版本（例如國際版與國內版），它們的套件名稱不同，請依版本號確認選的是舊國際版。

## 如何查出目前安裝的 Bilibili 套件名稱與版本號

### 方法 A：只用手機（不需電腦）

- **系統設定**：設定 → 應用程式 → 找到 Bilibili →「應用程式資訊」，最下方通常有版本號。這裡看不到套件名稱，套件名稱請用 UWU 的清單挑選，或用下面其中一種。
- **UWU 自己**：在「設定套件」的清單挑選後，卡片就會同時顯示套件名稱與版本號。
- **Termux（選用）**：`pm list packages | grep -i bili` 可列出套件名稱。

### 方法 B：ADB（電腦）

手機開啟「開發人員選項 → USB 偵錯」並連接電腦後：

```bash
# 1) 找出套件名稱（可能出現多個，注意區分國際版／國內版）
adb shell pm list packages | grep -i bili
#   例：package:<套件名稱>

# 2) 查版本號（把 <套件名稱> 換成上一步的結果）
adb shell dumpsys package <套件名稱> | grep -E "versionName|versionCode"

# 3) 查這個套件的 APK 路徑（分割 APK 會列出多行：base.apk + split_*.apk）
adb shell pm path <套件名稱>

# 4) 查它的啟動 Activity
adb shell cmd package resolve-activity --brief <套件名稱>
```

Windows PowerShell 沒有 grep，可改用 `findstr`：
`adb shell pm list packages | findstr /i bili`

這些指令都是唯讀查詢，不會安裝、更新或解除安裝任何東西。

### 方法 C：從 bilibili.apks 檢查（可選，需 Android SDK build-tools）

```bash
tools/inspect_apks.sh /path/to/bilibili.apks
```

會列出分割 APK 結構、套件名稱、版本號、啟動 Activity（只解壓到暫存資料夾，唯讀）。
手機上安裝的版本若與 `.apks` 不同，以手機實際安裝的為準。

## 保護舊版 Bilibili

- UWU 只呼叫 `getLaunchIntentForPackage` 啟動**手機上現有**的那一份；不含任何安裝、更新、解除安裝程式碼，也不下載任何檔案。
- 請**不要**對 Bilibili 再執行 `install-apks`，並建議在應用商店關閉該 App 的自動更新。

## 編譯與安裝

**前提**：電腦需能連到 `services.gradle.org`、`dl.google.com`、`maven.google.com`、Maven Central（首次編譯會下載 Gradle 8.10.2、Android Gradle Plugin 8.7.3、Kotlin 2.0.21、Compose 套件）。需要 JDK 17 以上（Android Studio 內建的 JDK 即可）。

1. 用 Android Studio（Ladybug 2024.2 或更新）開啟 `UWU-DualStation` 資料夾。專案已含 Gradle Wrapper（`gradlew`、`gradlew.bat`、`gradle/wrapper/`）。
2. 首次開啟時 Android Studio 會自動建立 `local.properties`（內含 `sdk.dir`），並提示安裝 Android SDK Platform 35，照提示安裝即可。
   若用命令列編譯，請自行建立 `local.properties`，內容例如 `sdk.dir=/Users/你/Library/Android/sdk`，或設定環境變數 `ANDROID_HOME`。
3. 等 Gradle Sync 完成。
4. 手機開啟「開發人員選項 → USB 偵錯」並連接電腦。
5. 在 Android Studio 按 Run，或用命令列：
   ```bash
   ./gradlew assembleDebug          # Windows：gradlew.bat assembleDebug
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   `-r` 只會覆蓋安裝 UWU 自己，不影響 YouTube／Bilibili。
   Debug APK 已用 debug 金鑰簽署，可直接安裝；發行用 release APK 需另行建立簽署金鑰。

## 本次修訂內容（相對於上一版 v0.1）

- 新增 Gradle Wrapper：`gradlew`、`gradlew.bat`、`gradle/wrapper/gradle-wrapper.jar`、`gradle-wrapper.properties`（Gradle 8.10.2，與 AGP 8.7.3 相容）。
- 移除 AppLauncher 中已不再使用的舊程式碼（`AppTargets.bilibili(context)`）。
- 逐檔檢查 Kotlin／Compose／Manifest／Gradle 設定：未發現需要修改的錯誤（Compose BOM 2024.10.01 對應 Material3 1.3.0，`surfaceContainerHigh`、`LifecycleEventEffect` 等 API 皆可用；compileSdk 35 需要 AGP 8.6 以上，已使用 8.7.3）。
- 啟動邏輯、App 內 Bilibili 套件設定、從已安裝 App 清單選擇：維持原樣，沒有新增功能，也沒有開始 v0.2。

## 測試結果（誠實說明）

**沒有編譯成功，也沒有產出 APK。** 產生這份專案的雲端環境無法連到 Gradle 官方站、Google Maven／Android SDK、Maven Central（皆回 403，且沒有本機 Android SDK 或已快取的依賴），因此無法執行 `assembleDebug`。

| 項目 | 結果 |
|------|------|
| Gradle Wrapper 產生 | 通過（`gradlew` 可啟動，並嘗試下載 Gradle 8.10.2；下載因環境限制被擋） |
| 編譯 `assembleDebug` | **未執行（環境無法連線）** |
| 產出 APK | **無** |
| Kotlin 靜態檢查（括號平衡、import 使用、跨檔符號定義、無殘留舊參照） | 通過 |
| 手機實機測試（開啟 YouTube／Bilibili） | **未執行**，請依下方測試清單在你的手機驗證 |

編譯若出現錯誤，請把完整訊息貼回來，我會依實際錯誤修正。

## 測試清單

| # | 情境 | 預期 |
|---|------|------|
| 1 | 首次開啟（未設定 Bilibili） | Bilibili 卡片顯示「尚未設定」，點開啟會出現說明，不閃退 |
| 2 | 「設定套件」→ 從清單選擇舊國際版 → 儲存 | 卡片顯示套件名稱、版本號與原生圖示 |
| 3 | 按 Bilibili「開啟」 | 啟動手機上原本的舊版 Bilibili；可看直向短影片 |
| 4 | 按 YouTube「開啟」 | 啟動官方 YouTube；可看 Shorts |
| 5 | 手動輸入錯誤的套件名稱 | 顯示「未安裝（或套件名稱不正確）」，不閃退 |
| 6 | 預期版本號填成不同值 | 卡片紅字提醒版本不同，仍可啟動 |
| 7 | 關閉再重開 UWU | Bilibili 設定仍保留 |
| 8 | 測試前後比對 Bilibili 版本 | versionName／versionCode 不變 |

## 專案結構

```
gradlew / gradlew.bat / gradle/wrapper/   Gradle Wrapper
app/src/main/java/com/uwu/dualstation/
  MainActivity.kt           入口
  AppLauncher.kt            PackageManager 檢查、啟動、列出可啟動 App
  BilibiliConfig.kt         Bilibili 設定值（SharedPreferences）
  ui/HomeScreen.kt          首頁
  ui/BilibiliConfigDialog.kt 設定對話框與已安裝 App 挑選
  ui/Theme.kt               主題（Android 12+ 使用動態色彩）
tools/inspect_apks.sh       檢查 bilibili.apks（選用）
```

## 後續版本

- v0.2：統一下載中心（只列出 UWU 有權存取、由 UWU 管理的檔案；不讀取 YouTube／Bilibili 的私有或受保護快取）
- v0.3：設定（版本資訊、主題、關於）、介面完善
- v1.0：研究在合法且技術可行的前提下，是否能將兩平台功能整合進 UWU 內部
