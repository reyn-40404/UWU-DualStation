package com.uwu.dualstation

import android.content.Context

/**
 * Bilibili 的設定值（使用者可在 App 內修改，不需重新編譯）。
 * 套件名稱預設為空：UWU 不內建、不猜測，必須由使用者從手機上實際安裝的版本確認或挑選。
 */
object BilibiliConfig {
    private const val PREFS = "uwu_prefs"
    private const val KEY_PACKAGE = "bilibili_package"
    private const val KEY_EXPECTED_VERSION = "bilibili_expected_version"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getPackage(context: Context): String =
        prefs(context).getString(KEY_PACKAGE, "").orEmpty()

    fun getExpectedVersion(context: Context): String =
        prefs(context).getString(KEY_EXPECTED_VERSION, "").orEmpty()

    fun save(context: Context, packageName: String, expectedVersionName: String) {
        prefs(context).edit()
            .putString(KEY_PACKAGE, packageName.trim())
            .putString(KEY_EXPECTED_VERSION, expectedVersionName.trim())
            .apply()
    }
}
