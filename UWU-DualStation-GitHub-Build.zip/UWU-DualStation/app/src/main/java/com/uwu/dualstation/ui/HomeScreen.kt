package com.uwu.dualstation.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.uwu.dualstation.AppLauncher
import com.uwu.dualstation.AppStatus
import com.uwu.dualstation.AppTarget
import com.uwu.dualstation.AppTargets
import com.uwu.dualstation.BilibiliConfig
import com.uwu.dualstation.LaunchResult
import kotlinx.coroutines.launch

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val snackbarHost = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // 每次回到 UWU 就重新檢查安裝狀態（使用者可能剛裝好或更新了某個 App）
    var refreshTick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refreshTick++ }

    // Bilibili 設定值：使用者在 App 內修改，存於 SharedPreferences
    var bilibiliPackage by remember { mutableStateOf(BilibiliConfig.getPackage(context)) }
    var bilibiliExpected by remember { mutableStateOf(BilibiliConfig.getExpectedVersion(context)) }
    var showConfig by remember { mutableStateOf(false) }

    val youtube = AppTargets.youtube
    val bilibili = AppTarget("Bilibili", bilibiliPackage, bilibiliExpected)

    val youtubeStatus = remember(refreshTick) { AppLauncher.inspect(context, youtube) }
    val bilibiliStatus = remember(refreshTick, bilibiliPackage, bilibiliExpected) {
        AppLauncher.inspect(context, bilibili)
    }

    fun open(target: AppTarget) {
        val message = launchMessage(AppLauncher.launch(context, target), target)
        if (message != null) {
            scope.launch { snackbarHost.showSnackbar(message) }
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHost) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("雙站 UWU", style = MaterialTheme.typography.headlineLarge)
            Text(
                "一個入口，打開手機上的 YouTube 與 Bilibili",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))

            PlatformCard(
                status = youtubeStatus,
                fallbackIcon = Icons.Filled.PlayCircle,
                refreshTick = refreshTick,
                onOpen = { open(youtube) },
            )
            PlatformCard(
                status = bilibiliStatus,
                fallbackIcon = Icons.Filled.OndemandVideo,
                refreshTick = refreshTick,
                onOpen = { open(bilibili) },
                onConfigure = { showConfig = true },
            )

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                ComingSoonTile(
                    title = "下載中心",
                    tag = "v0.2",
                    icon = Icons.Filled.Download,
                    modifier = Modifier.weight(1f),
                )
                ComingSoonTile(
                    title = "設定",
                    tag = "v0.3",
                    icon = Icons.Filled.Settings,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    if (showConfig) {
        BilibiliConfigDialog(
            initialPackage = bilibiliPackage,
            initialExpectedVersion = bilibiliExpected,
            onSave = { pkg, version ->
                BilibiliConfig.save(context, pkg, version)
                bilibiliPackage = pkg
                bilibiliExpected = version
                showConfig = false
            },
            onDismiss = { showConfig = false },
        )
    }
}

@Composable
private fun PlatformCard(
    status: AppStatus,
    fallbackIcon: ImageVector,
    refreshTick: Int,
    onOpen: () -> Unit,
    onConfigure: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    // 直接使用手機上該 App 的原生圖示，不內建任何商標圖檔
    val iconBitmap = remember(refreshTick, status.target.packageName, status.installed) {
        AppLauncher.loadIcon(context, status.target.packageName)
            ?.toBitmap(width = 192, height = 192)
            ?.asImageBitmap()
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (iconBitmap != null) {
                    Image(
                        bitmap = iconBitmap,
                        contentDescription = status.target.displayName,
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(14.dp)),
                    )
                } else {
                    Icon(
                        imageVector = fallbackIcon,
                        contentDescription = status.target.displayName,
                        modifier = Modifier.size(60.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(status.target.displayName, style = MaterialTheme.typography.titleLarge)
                    Text(
                        statusText(status),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (status.versionMismatch) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                    if (status.configured) {
                        Text(
                            status.target.packageName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Button(onClick = onOpen) { Text("開啟") }
            }
            if (onConfigure != null) {
                TextButton(onClick = onConfigure) { Text("設定套件") }
            }
        }
    }
}

@Composable
private fun ComingSoonTile(
    title: String,
    tag: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.alpha(0.6f),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(icon, contentDescription = title, modifier = Modifier.size(32.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                "即將推出 · $tag",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun statusText(status: AppStatus): String = when {
    !status.configured -> "尚未設定 · 請點下方「設定套件」"
    !status.installed -> "未安裝（或套件名稱不正確）"
    status.versionMismatch ->
        "已安裝 · v${status.versionName}（與預期 v${status.target.expectedVersionName} 不同）"
    else -> "已安裝 · v${status.versionName ?: "?"}"
}

/** 啟動結果 → 給使用者看的訊息；成功時回傳 null。 */
private fun launchMessage(result: LaunchResult, target: AppTarget): String? = when (result) {
    LaunchResult.Success -> null
    LaunchResult.NotConfigured ->
        "尚未設定 ${target.displayName} 的套件名稱。請點卡片下方的「設定套件」，輸入或從清單挑選。"
    LaunchResult.NotInstalled ->
        "找不到 ${target.displayName}（${target.packageName}）。請確認套件名稱，UWU 不會代為安裝或更新。"
    LaunchResult.NoLaunchIntent ->
        "${target.displayName} 已安裝，但找不到可啟動的入口。"
    is LaunchResult.Failed ->
        "無法啟動 ${target.displayName}：${result.reason}"
}
