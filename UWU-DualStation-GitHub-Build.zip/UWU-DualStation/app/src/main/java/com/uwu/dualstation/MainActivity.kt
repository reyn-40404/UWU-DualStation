package com.uwu.dualstation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.uwu.dualstation.ui.HomeScreen
import com.uwu.dualstation.ui.UwuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UwuTheme {
                HomeScreen()
            }
        }
    }
}
