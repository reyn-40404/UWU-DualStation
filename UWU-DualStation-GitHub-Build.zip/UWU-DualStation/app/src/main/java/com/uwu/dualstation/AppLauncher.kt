package com.uwu.dualstation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat

/** 要啟動的外部 App。packageName 為空代表「尚未設定」。 */
data class AppTarget(
    val displayName: String,
    val packageName: String,
    val expectedVersionName: String = "",
)

object AppTargets {
    /** YouTube 官方 App 的套件名稱（固定，公開已知）。 */
    const val YOUTUBE_PACKAGE = "com.google.android.youtube"

    val youtube = AppTarget("YouTube", YOUTUBE_PACKAGE)
    // Bilibili 的套件名稱與預期版本來自使用者在 App 內的設定（BilibiliConfig，預設為空），
    // 由 HomeScreen 組成 AppTarget。
}

/** 以 PackageManager 查到的安裝狀態（唯讀，不會修改任何 App）。 */
data class AppStatus(
    val target: AppTarget,
    val configured: Boolean,
    val installed: Boolean,
    val versionName: String? = null,
    val versionCode: Long? = null,
) {
    val versionMismatch: Boolean
        get() = installed &&
            target.expectedVersionName.isNotBlank() &&
            versionName != target.expectedVersionName
}

/** 手機上可從桌面啟動的 App（供使用者挑選 Bilibili 用）。 */
data class InstalledApp(val label: String, val packageName: String)

sealed interface LaunchResult {
    data object Success : LaunchResult
    data object NotConfigured : LaunchResult
    data object NotInstalled : LaunchResult
    data object NoLaunchIntent : LaunchResult
    data class Failed(val reason: String) : LaunchResult
}

object AppLauncher {

    fun inspect(context: Context, target: AppTarget): AppStatus {
        if (target.packageName.isBlank()) {
            return AppStatus(target, configured = false, installed = false)
        }
        val pm = context.packageManager
        return try {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(target.packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(target.packageName, 0)
            }
            AppStatus(
                target = target,
                configured = true,
                installed = true,
                versionName = info.versionName,
                versionCode = PackageInfoCompat.getLongVersionCode(info),
            )
        } catch (_: PackageManager.NameNotFoundException) {
            AppStatus(target, configured = true, installed = false)
        }
    }

    /** 使用手機上「已安裝」的該套件的官方啟動入口；不安裝、不更新、不替換。 */
    fun launch(context: Context, target: AppTarget): LaunchResult {
        val status = inspect(context, target)
        if (!status.configured) return LaunchResult.NotConfigured
        if (!status.installed) return LaunchResult.NotInstalled

        val intent = context.packageManager.getLaunchIntentForPackage(target.packageName)
            ?: return LaunchResult.NoLaunchIntent

        return try {
            context.startActivity(intent)
            LaunchResult.Success
        } catch (e: ActivityNotFoundException) {
            LaunchResult.Failed(e.message ?: "找不到可啟動的 Activity")
        } catch (e: SecurityException) {
            LaunchResult.Failed(e.message ?: "沒有啟動權限")
        }
    }

    /** 取得該 App 在手機上的原生圖示；未安裝時回傳 null。 */
    fun loadIcon(context: Context, packageName: String): Drawable? {
        if (packageName.isBlank()) return null
        return try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (_: PackageManager.NameNotFoundException) {
            null
        }
    }

    /** 列出手機上所有可從桌面啟動的 App（需要 manifest 的 <queries> 宣告）。 */
    fun listLaunchableApps(context: Context): List<InstalledApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return resolved
            .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .filter { it.packageName != context.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
